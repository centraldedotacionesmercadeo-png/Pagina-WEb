document.addEventListener("DOMContentLoaded", () => {
    console.log("Central de Dotaciones - Página cargada correctamente");
});
