document.addEventListener('DOMContentLoaded', () => {
  const track = document.querySelector('.carousel-track');
  let offset = 0;

  setInterval(() => {
    offset -= 160; // desplaza la imagen
    if (Math.abs(offset) >= track.scrollWidth / 2) {
      offset = 0;
    }
    track.style.transform = `translateX(${offset}px)`;
    track.style.transition = "transform 0.5s ease-in-out";
  }, 2000); // cada 2 segundos
});
